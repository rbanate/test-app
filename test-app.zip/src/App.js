import React, { useEffect, useState } from "react";

import logo from "./logo.svg";
import "./App.css";

function App() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const token =
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjA2MGZmYWI4OGFhOWYyNzI4YmZlMzAwNjYyOWQ5N2UzYzgzM2NkYmM0ZWQ5YjAyODNmM2ZhYjRlYmU3NDBlZTdmNjFlNTQzNDg5YTM2ZjRhIn0.eyJhdWQiOiI3IiwianRpIjoiMDYwZmZhYjg4YWE5ZjI3MjhiZmUzMDA2NjI5ZDk3ZTNjODMzY2RiYzRlZDliMDI4M2YzZmFiNGViZTc0MGVlN2Y2MWU1NDM0ODlhMzZmNGEiLCJpYXQiOjE2MjkxNjU5MjksIm5iZiI6MTYyOTE2NTkyOSwiZXhwIjoxNjYwNzAxOTI5LCJzdWIiOiIyNzQ0NCIsInNjb3BlcyI6WyJwYXRpZW50Il19.e1SmCMCfI62fBYNhtLjvjOOsDZf0_aUjEoGBFkyaKWwQQiBUFv5Hr6Rz65QlQ79uAcY_CazgZxxx_BwhYWxRt3MDj_ilW_XfL_dQbVsdTHbjVvSMgM0DCASZPUyOvFuW_yyf1yYyn9n4DEn8bAy-NyRmWv25zxNniyrKonSi3_2sSMRijSeoogZwvPsdOoMss2fHDDQzLwHueW1aSD-hKE1kl3jQSE51qMnHjT2DH5ulLJHOyp63AIox4s6OM1Trkozmb9klw9HXeDrRD6UAUPUPsYqV4AFTRlBLtVeGVstkgFOItFhblwsmWl_LmYLfMPvPWDnmarazfxdub3qQz402YUtrdpiSw_wvRu70M7nFksoIiG0ZhSzCwynmHeA-SzQMrOHm_kSQLYXsGnZGuQISJGgAVcZgdTDLLwRVy2w1kDp-fljgB9zDIdRrDURuy84hl3RrfY2gROB4uqer2v-hoEIGE-dmWu-XdqLNNgUQspnKsK6H4xcu8RECPkhJXhZ7s8otMQErBPgOFKoexoVEkpXkV7IDA9JqQWDy4I3ErUaibVoKtTD9d0-90A5ZYuc2x0RPpDAOI6OJ1mT0wBj7LQeTA2YtCqsI2j8J9fPoSYdQocSoI126Vx9yEEo3mKrqtxjF6WRzc5T9hck84e-G3f9L_vFisQGcjiPQ1EM";
  useEffect(() => {
    const options = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        authorization: `Bearer ${token}`,
      },
    };
    fetch("https://integration.akosmd.com/api/patient/me", options)
      .then((res) => res.json())
      .then(
        (result) => {
          setTimeout(() => {
            setLoading(!result);
          }, 5000);
        },

        (error) => {
          setError(error);
        }
      );
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        {loading && (
          <>
            <img src={logo} className="App-logo" alt="logo" />
            <p>Please wait while loading...</p>
          </>
        )}
        {!loading && <p>Page has loaded...</p>}
        {error && <p>An error has occurred...</p>}
      </header>
    </div>
  );
}

export default App;
